// Implement these only after a provider is selected. Never trust a success=true URL.
export async function createCheckout(){throw Object.assign(Error('مزوّد الدفع لم يُربط بعد.'),{status:503});}
// Verify the provider signature and paid order using its official API. Bind the return to the buyer.
export async function completePayment(){throw Object.assign(Error('مزوّد الدفع لم يُربط بعد.'),{status:503});}
// Once the provider has verified payment, call store.issuePurchase({email,provider,reference}).
// Send `${PUBLIC_ORIGIN}/signup.html#claim=${token}` only to that verified buyer's return/email flow.
// Do not expose a public API that accepts a caller-supplied verified/paid flag.

// Checkout return URL: `${PUBLIC_ORIGIN}/payment-success.html`.
// completePayment must verify the provider result AND the original buyer-bound checkout nonce,
// then return {signupUrl: `${PUBLIC_ORIGIN}/signup.html#claim=${ticket.token}`}.
// createCheckout returns {checkoutUrl: "https://approved-provider/checkout/..."}.
