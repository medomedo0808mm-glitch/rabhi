-- Run once in the Supabase SQL editor. No public signup grants purchase access.
create table if not exists public.ribhi_purchase_tickets (
 id uuid primary key default gen_random_uuid(), email text not null,
 provider text not null, reference text not null, token_hash text not null unique,
 status text not null default 'paid' check (status in ('paid','registering','redeemed','revoked')),
 expires_at timestamptz not null default now()+interval '7 days',
 reservation uuid, reserved_at timestamptz, user_id uuid references auth.users(id),
 created_at timestamptz not null default now(), unique(provider,reference)
);
create table if not exists public.ribhi_entitlements (
 user_id uuid primary key references auth.users(id) on delete cascade,
 enabled boolean not null default false,
 source_ticket uuid unique references public.ribhi_purchase_tickets(id),
 updated_at timestamptz not null default now()
);
create table if not exists public.ribhi_vault (
 user_id uuid primary key references auth.users(id) on delete cascade,
 ciphertext text not null check (octet_length(ciphertext)<=3000000),
 revision bigint not null default 1, updated_at timestamptz not null default now()
);
alter table public.ribhi_purchase_tickets enable row level security;
alter table public.ribhi_entitlements enable row level security;
alter table public.ribhi_vault enable row level security;
revoke all on public.ribhi_purchase_tickets,public.ribhi_entitlements,public.ribhi_vault from anon,authenticated;
grant select on public.ribhi_entitlements,public.ribhi_vault to authenticated;
grant all on public.ribhi_purchase_tickets,public.ribhi_entitlements,public.ribhi_vault to service_role;
drop policy if exists entitlement_owner on public.ribhi_entitlements;
create policy entitlement_owner on public.ribhi_entitlements for select to authenticated using ((select auth.uid())=user_id);
drop policy if exists vault_owner on public.ribhi_vault;
create policy vault_owner on public.ribhi_vault for select to authenticated using (
 (select auth.uid())=user_id and exists(select 1 from public.ribhi_entitlements e where e.user_id=(select auth.uid()) and e.enabled)
);
create or replace function public.ribhi_issue_ticket(p_email text,p_provider text,p_reference text,p_hash text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare t public.ribhi_purchase_tickets;
begin
 if length(p_email)>254 or p_email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' or length(p_provider) not between 1 and 50 or length(p_reference) not between 3 and 200 or p_hash !~ '^[a-f0-9]{64}$' then raise exception 'RIBHI_INVALID_TICKET'; end if;
 insert into public.ribhi_purchase_tickets(email,provider,reference,token_hash) values(lower(trim(p_email)),p_provider,p_reference,p_hash) returning * into t;
 return jsonb_build_object('id',t.id,'expires_at',t.expires_at);
end $$;
create or replace function public.ribhi_ticket_status(p_hash text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare t public.ribhi_purchase_tickets;
begin
 select * into t from public.ribhi_purchase_tickets where token_hash=p_hash;
 if not found or t.status not in ('paid','registering') or t.expires_at<=now() then raise exception 'RIBHI_INVALID_TICKET'; end if;
 return jsonb_build_object('email',t.email,'expires_at',t.expires_at,'status',t.status);
end $$;
create or replace function public.ribhi_reserve_ticket(p_hash text,p_email text,p_reservation uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare t public.ribhi_purchase_tickets;
begin
 select * into t from public.ribhi_purchase_tickets where token_hash=p_hash for update;
 if not found or t.status in ('redeemed','revoked') or t.expires_at<=now() or t.email<>lower(trim(p_email)) or p_reservation is null then raise exception 'RIBHI_INVALID_TICKET'; end if;
 if t.status='registering' and t.reserved_at>now()-interval '10 minutes' then raise exception 'RIBHI_BUSY'; end if;
 update public.ribhi_purchase_tickets set status='registering',reservation=p_reservation,reserved_at=now() where id=t.id;
 return jsonb_build_object('id',t.id,'email',t.email);
end $$;
create or replace function public.ribhi_release_ticket(p_hash text,p_reservation uuid)
returns void language sql security definer set search_path='' as $$
 update public.ribhi_purchase_tickets set status='paid',reservation=null,reserved_at=null where token_hash=p_hash and status='registering' and reservation=p_reservation;
$$;
create or replace function public.ribhi_complete_ticket(p_hash text,p_reservation uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare t public.ribhi_purchase_tickets; uid uuid;
begin
 select * into t from public.ribhi_purchase_tickets where token_hash=p_hash for update;
 if not found or t.status<>'registering' or t.reservation<>p_reservation or t.expires_at<=now() then raise exception 'RIBHI_INVALID_TICKET'; end if;
 select u.id into uid from auth.users u where lower(u.email)=t.email and u.raw_app_meta_data->>'ribhi_ticket_id'=t.id::text;
 if uid is null then raise exception 'RIBHI_INVALID_TICKET'; end if;
 insert into public.ribhi_entitlements(user_id,enabled,source_ticket) values(uid,true,t.id)
 on conflict(user_id) do update set enabled=true,source_ticket=excluded.source_ticket,updated_at=now();
 update public.ribhi_purchase_tickets set status='redeemed',user_id=uid where id=t.id;
 return jsonb_build_object('user_id',uid);
end $$;
create or replace function public.ribhi_save_vault(p_ciphertext text,p_expected_revision bigint)
returns bigint language plpgsql security definer set search_path='' as $$
declare uid uuid := auth.uid(); current_revision bigint; result_revision bigint;
begin
 if uid is null or not exists(select 1 from public.ribhi_entitlements e where e.user_id=uid and e.enabled) then raise exception 'RIBHI_UNAUTHORIZED'; end if;
 if p_expected_revision is null or p_expected_revision<0 or p_ciphertext is null or octet_length(p_ciphertext)>3000000 or p_ciphertext not like 'v1.%' then raise exception 'RIBHI_INVALID_STATE'; end if;
 -- Serialize the first insert and subsequent updates for this exact user, across server instances.
 perform pg_advisory_xact_lock(hashtextextended(uid::text,0));
 select revision into current_revision from public.ribhi_vault where user_id=uid for update;
 if coalesce(current_revision,0)<>p_expected_revision then raise exception 'RIBHI_CONFLICT'; end if;
 result_revision:=coalesce(current_revision,0)+1;
 insert into public.ribhi_vault(user_id,ciphertext,revision) values(uid,p_ciphertext,result_revision)
 on conflict(user_id) do update set ciphertext=excluded.ciphertext,revision=excluded.revision,updated_at=now();
 return result_revision;
end $$;
revoke all on function public.ribhi_issue_ticket(text,text,text,text),public.ribhi_ticket_status(text),public.ribhi_reserve_ticket(text,text,uuid),public.ribhi_release_ticket(text,uuid),public.ribhi_complete_ticket(text,uuid),public.ribhi_save_vault(text,bigint) from public,anon,authenticated;
grant execute on function public.ribhi_issue_ticket(text,text,text,text),public.ribhi_ticket_status(text),public.ribhi_reserve_ticket(text,text,uuid),public.ribhi_release_ticket(text,uuid),public.ribhi_complete_ticket(text,uuid) to service_role;
grant execute on function public.ribhi_save_vault(text,bigint) to authenticated;
