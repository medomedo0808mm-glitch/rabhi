const CACHE='ribhi-public-pwa-v1';
const PREFIX='ribhi-public-pwa-';
// Strict public-only list. Never cache dashboard HTML, authentication, reports or account APIs.
const PUBLIC=['/offline.html','/manifest.json','/assets/pwa.js','/assets/pwa.css','/icons/icon-192.png','/icons/icon-512.png','/icons/icon-maskable-512.png','/icons/apple-touch-icon.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(PUBLIC)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith(PREFIX)&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/'))return;
 if(request.mode==='navigate'){
  // Always revalidate the account at the server, including installed-app launches.
  event.respondWith(fetch(new Request(request,{cache:'no-store'})).catch(async()=>{const response=await (await caches.open(CACHE)).match('/offline.html');return response||new Response('ربحي يحتاج اتصالًا بالخادم. أعد المحاولة عند عودة الشبكة.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});}));return;
 }
 if(!url.search&&PUBLIC.includes(url.pathname)){event.respondWith((async()=>{const cache=await caches.open(CACHE),hit=await cache.match(url.pathname);if(hit)return hit;const response=await fetch(request);if(response.ok&&response.type==='basic')await cache.put(url.pathname,response.clone());return response;})());}
});
