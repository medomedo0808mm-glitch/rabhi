import {createSupabaseStore} from './lib/supabase-store.mjs';
import {fileURLToPath} from 'node:url';
const [action,email,reference]=process.argv.slice(2);
if(action!=='issue'){console.log('After confirming the real purchase: node --env-file=.env cloud-admin.mjs issue buyer@example.com verified-receipt-reference');process.exit(1);}
const store=createSupabaseStore({url:process.env.SUPABASE_URL,key:process.env.SUPABASE_PUBLISHABLE_KEY||process.env.SUPABASE_ANON_KEY,serviceKey:process.env.SUPABASE_SECRET_KEY||process.env.SUPABASE_SERVICE_ROLE_KEY,encryptionKey:process.env.RIBHI_ENCRYPTION_KEY,sessionPath:fileURLToPath(new URL('./data/cloud-sessions.sqlite',import.meta.url))});
try{const ticket=await store.issuePurchase({email,provider:'owner-verified',reference});console.log(new URL('/signup.html#claim='+ticket.token,process.env.PUBLIC_ORIGIN).href);console.log('Single-use registration link. Send privately to this buyer. Expires: '+ticket.expires);}finally{store.close();}
