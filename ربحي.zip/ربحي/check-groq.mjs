import {loadProjectEnv} from './lib/config.mjs';
import {createAdvisor} from './lib/advisor.mjs';
loadProjectEnv();
try{const result=await createAdvisor().ask({question:'اختبار اتصال فقط: أجب بكلمة جاهز.',snapshot:{}});console.log('اتصال Groq ناجح. '+result.answer.slice(0,200));}catch(error){console.error(error.message);process.exitCode=1;}
