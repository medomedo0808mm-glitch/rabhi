import {createStore} from './lib/auth.mjs';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
const root=fileURLToPath(new URL('.',import.meta.url)),store=createStore(process.env.RIBHI_DB_PATH||join(root,'data','ribhi.sqlite'));
const [action,email,reference]=process.argv.slice(2);
try{
  if(action==='create'){
    const password=randomBytes(18).toString('base64url');await store.create(email,password);
    console.log('Account created WITHOUT purchase permission.');console.log('Temporary password (share privately with this buyer): '+password);
  }else if(action==='grant'){store.grant(email,reference);console.log('Purchase permission recorded.');}
  else if(action==='revoke'){store.revoke(email);console.log('Purchase permission revoked and sessions closed.');}
  else console.log('Owner-only commands:\nnode admin.mjs create buyer@example.com\nnode admin.mjs grant buyer@example.com verified-receipt-reference\nnode admin.mjs revoke buyer@example.com');
}catch(e){console.error(e.message);process.exitCode=1;}finally{store.close();}
