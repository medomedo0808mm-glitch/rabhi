import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../private/dashboard.html',import.meta.url),'utf8');
const scopeCode=html.slice(html.indexOf('function scopeText(data)'),html.indexOf('function updateScope()'));
test('advisor scope label follows the English interface language',()=>{
 const ctx={document:{documentElement:{lang:'en'}}};vm.createContext(ctx);vm.runInContext(scopeCode,ctx);
 assert.equal(ctx.scopeText({calculator:{currency:'USD'},business:{currency:'EGP',period:'2026-10'}}),'Calculator: USD · Business: EGP · Month: 2026-10');
 assert.match(ctx.scopeText({}),/No new figures/);
});
test('English interface text uses US SaaS spelling and has no stray Arabic in the advisor labels',()=>{
 assert(!/\bAnalyse\b|\banalyse\b(?! *=)/.test(html.replace(/data-ai-quick="analyse"/g,'').replace(/analyse:\{/g,'').replace(/quickPrompts\[key\]/g,'')));
 assert(html.includes("quick_analyse:'Analyze my figures'"));
 assert(html.includes('const quickPromptsEn='));
});
