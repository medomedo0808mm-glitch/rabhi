import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../private/dashboard.html',import.meta.url),'utf8');
const code=html.slice(html.indexOf('async function submitQuestion('),html.indexOf('\nfunction scriptLabels()',html.indexOf('async function submitQuestion(')));
function fixture({valid=true,fetcher,share=true}={}){
 const buttons=['analyse','offer','risk'].map(key=>({dataset:{aiQuick:key},disabled:false,addEventListener(){}})),calls=[],bubbles=[],opens=[],snapshots=[];
 const shareControl={checked:share};
 const ctx={$:()=>shareControl,pending:false,retryUntil:0,times:[],history:[{role:'user',text:'old product'}],busyText:'BUSY',question:{value:'unfinished typed question'},send:{},log:{setAttribute(){}},status:{},document:{querySelectorAll:()=>buttons},form:{addEventListener(){},reportValidity:()=>true},window:{RIBHI_CALCULATOR:{validInputs:()=>valid},RIBHI_SESSION:{csrf:'test-csrf'}},open:(...args)=>opens.push(args),numericSnapshot:force=>{snapshots.push(force);return {calculator:{currency:'EGP',sell:150,ads:25,results:{profit:33.3}}};},updateScope(){},scopeText:()=> 'EGP',bubble:(text,role)=>{bubbles.push({text,role});return {remove(){}};},AbortSignal,fetch:async(url,options)=>{calls.push({url,options,body:JSON.parse(options.body)});return fetcher?await fetcher():{ok:true,json:async()=>({answer:'• profit\n• risk\n• action'})};}};
 vm.createContext(ctx);vm.runInContext(code,ctx);return {ctx,calls,bubbles,opens,snapshots,buttons,shareControl};
}
test('all three actions send current figures once, isolate old history and preserve typed draft',async()=>{
 const f=fixture();for(const key of ['analyse','offer','risk'])await f.ctx.runQuickAction(key);
 assert.equal(f.calls.length,3);assert.deepEqual(f.snapshots,[true,true,true]);
 for(const call of f.calls){assert.equal(call.url,'/api/advisor');assert.equal(call.options.headers['X-CSRF-Token'],'test-csrf');assert.equal(call.body.snapshot.calculator.sell,150);assert.deepEqual(call.body.history,[]);assert(call.body.question.length>80);}
 assert.match(f.calls[1].body.question,/خصم/);assert.match(f.calls[2].body.question,/المرتجعات/);
 assert.equal(f.ctx.question.value,'unfinished typed question');assert.deepEqual(f.opens,[[true,false],[true,false],[true,false]]);
 assert(!f.bubbles.some(b=>b.role==='user'&&b.text===f.calls[0].body.question));assert(f.bubbles.some(b=>b.role==='user'&&b.text.includes('حلل أرقامي')));
 assert(f.buttons.every(b=>b.disabled===false));
});
test('invalid figures and cooldown prevent requests',async()=>{
 const invalid=fixture({valid:false});await invalid.ctx.runQuickAction('risk');assert.equal(invalid.calls.length,0);assert.equal(invalid.ctx.status.textContent,'لم تُرسل أي بيانات.');
 const limited=fixture();limited.ctx.retryUntil=Date.now()+60000;await limited.ctx.runQuickAction('analyse');assert.equal(limited.calls.length,0);assert(limited.bubbles.some(b=>b.text==='BUSY'));
});
test('double click is blocked while pending; provider failure re-enables actions',async()=>{
 let release;const waiting=new Promise(resolve=>{release=resolve;});const f=fixture({fetcher:()=>waiting});const request=f.ctx.runQuickAction('analyse');assert(f.buttons.every(b=>b.disabled));await f.ctx.runQuickAction('risk');assert.equal(f.calls.length,1);release({ok:false,status:429,json:async()=>({retryAfter:60})});await request;assert(f.buttons.every(b=>!b.disabled));assert(f.ctx.retryUntil>Date.now());assert.equal(f.ctx.question.value,'unfinished typed question');
});

test('sharing off sends a general question without calculator reads, validation or previous numeric history',async()=>{const f=fixture({valid:false,share:false});f.ctx.history=[{role:'user',text:'PRIVATE FIGURES',mode:'calculator'},{role:'model',text:'PRIVATE FIGURES',mode:'calculator'}];f.ctx.numericSnapshot=()=>{throw Error('must not read calculator');};await f.ctx.submitQuestion('كيف أختار اسماً لمتجري؟');assert.equal(f.calls.length,1);assert.equal(f.calls[0].body.mode,'general');assert.deepEqual(f.calls[0].body.snapshot,{});assert.deepEqual(f.calls[0].body.history,[]);assert(!JSON.stringify(f.calls).includes('PRIVATE FIGURES'));await f.ctx.submitQuestion('اقترح خطة تسويق');assert.equal(f.calls[1].body.history.length,2);assert.equal(f.calls[1].body.history[0].mode,'general');});
test('sharing on keeps calculator context; explicit quick actions still include figures when checkbox is off',async()=>{const f=fixture({share:true});await f.ctx.submitQuestion('حلل الأرباح');assert.equal(f.calls[0].body.mode,'calculator');assert.equal(f.calls[0].body.snapshot.calculator.sell,150);f.shareControl.checked=false;await f.ctx.runQuickAction('risk');assert.equal(f.calls[1].body.mode,'calculator');assert.equal(f.calls[1].body.snapshot.calculator.sell,150);});

test('copywriting requests use only explicit product details, ignore calculator sharing and isolate prior history',async()=>{const f=fixture({share:true,valid:false});f.ctx.numericSnapshot=()=>{throw Error('must not read financial fields');};f.ctx.history=[{role:'user',text:'private numbers',mode:'calculator'}];await f.ctx.submitQuestion('Product: smart watch, price: 200 EGP',{task:'ad',isolated:true,label:'Facebook ad'});assert.equal(f.calls[0].body.task,'ad');assert.equal(f.calls[0].body.mode,'general');assert.deepEqual(f.calls[0].body.snapshot,{});assert.deepEqual(f.calls[0].body.history,[]);assert.equal(f.calls[0].body.question,'Product: smart watch, price: 200 EGP');assert.equal(f.ctx.question.value,'unfinished typed question');});
