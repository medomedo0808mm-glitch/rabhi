@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".env" (
  set "PORT=8791"
  set "PUBLIC_ORIGIN=http://127.0.0.1:8791"
  set "NODE_ENV=development"
  set "AUTH_PROVIDER=local"
)
where node >nul 2>nul
if not errorlevel 1 (
  node --env-file-if-exists=.env server.mjs
) else (
  if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
    "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --env-file-if-exists=.env server.mjs
  ) else (
    echo Install Node.js 24 or newer, then run this file again.
  )
)
pause
