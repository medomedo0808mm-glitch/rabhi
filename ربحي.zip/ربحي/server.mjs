import http from 'node:http';
import {loadProjectEnv} from './lib/config.mjs';
import {createAdvisor} from './lib/advisor.mjs';
import {readFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash,timingSafeEqual} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {isIP} from 'node:net';
import {createStore} from './lib/auth.mjs';
import {createSupabaseStore} from './lib/supabase-store.mjs';
import {createCheckout,completePayment} from './config/payment-provider.mjs';
const root=fileURLToPath(new URL('.',import.meta.url));
export function createApplication({origin='http://127.0.0.1:8788',dbPath=join(root,'data','ribhi.sqlite'),production=false,trustedProxyIps=[],authStore,authProvider=process.env.AUTH_PROVIDER||'local',advisor=createAdvisor()}={}){
 const allowed=new URL(origin);if(!['http:','https:'].includes(allowed.protocol)||allowed.pathname!=='/'||allowed.search||allowed.hash||allowed.username||allowed.password)throw Error('PUBLIC_ORIGIN must be a clean site origin.');
 const secure=allowed.protocol==='https:';if(production&&!secure)throw Error('Production requires HTTPS.');
 if(!Array.isArray(trustedProxyIps)||trustedProxyIps.some(ip=>!isIP(ip)))throw Error('Invalid trusted proxy IP.');
 if(!['local','supabase'].includes(authProvider))throw Error('AUTH_PROVIDER must be local or supabase');
 if(production&&authProvider!=='supabase'&&!authStore)throw Error('Production requires AUTH_PROVIDER=supabase.');
 const store=authStore||(authProvider==='supabase'?createSupabaseStore({url:process.env.SUPABASE_URL,key:process.env.SUPABASE_PUBLISHABLE_KEY||process.env.SUPABASE_ANON_KEY,serviceKey:process.env.SUPABASE_SECRET_KEY||process.env.SUPABASE_SERVICE_ROLE_KEY,encryptionKey:process.env.RIBHI_ENCRYPTION_KEY,sessionPath:dbPath}):createStore(dbPath)),limits=new Map();let activeLogins=0;
 const cookieName=secure?'__Host-ribhi_session':'ribhi_session',recoveryCookie=secure?'__Host-ribhi_recovery':'ribhi_recovery';
 function token(req,name=cookieName){const part=String(req.headers.cookie||'').split(';').map(v=>v.trim()).find(v=>v.startsWith(name+'='));const value=part?.slice(name.length+1);return /^[a-f0-9]{64}$/.test(value||'')?value:undefined;}
 function setCookie(res,value,maxAge){res.setHeader('Set-Cookie',`${cookieName}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure?'; Secure':''}`);}
 const same=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
 function ip(req){const peer=req.socket.remoteAddress||'';if(!trustedProxyIps.includes(peer))return peer;const chain=String(req.headers['x-forwarded-for']||'').split(',').map(v=>v.trim());return chain.length&&isIP(chain.at(-1))?chain.at(-1):peer;}
 function wait(key,max=10){const now=Date.now();if(limits.size>=10000)for(const [k,v]of limits)if(v.end<=now)limits.delete(k);let row=limits.get(key);if(!row||row.end<=now){if(limits.size>=10000)return 60;row={end:now+60000,n:0};limits.set(key,row);}return ++row.n>max?Math.ceil((row.end-now)/1000):0;}
 function send(req,res,status,data,type='application/json; charset=utf-8',extra={}){let bytes=Buffer.from(type.startsWith('application/json')?JSON.stringify(data):data);if(bytes.length>1024&&/(?:^|,)\s*gzip\s*(?:,|$)/.test(req.headers['accept-encoding']||'')){bytes=gzipSync(bytes);res.setHeader('Content-Encoding','gzip');res.setHeader('Vary','Accept-Encoding');}res.writeHead(status,{'Content-Type':type,'Content-Length':bytes.length,...extra});res.end(req.method==='HEAD'?undefined:bytes);}
 async function page(req,res,file,account){let html=(await readFile(join(root,file),'utf8')).replace(/\r\n?/g,'\n');if(account)html=html.replace('/*RIBHI_ACCOUNT*/',`window.RIBHI_ACCOUNT=${JSON.stringify({id:account.id}).replace(/</g,'\\u003c')};`);
  const hashes=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)].map(m=>`'sha256-${createHash('sha256').update(m[1]).digest('base64')}'`).join(' ');
  res.setHeader('Content-Security-Policy',`default-src 'none'; script-src 'self' https://cdn.jsdelivr.net/npm/chart.js@4.5.1/dist/chart.umd.min.js ${hashes||"'none'"}; style-src 'self' 'unsafe-inline'; font-src data:; img-src 'self' data:; manifest-src 'self'; worker-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; frame-src 'self'; object-src 'none'`);
  return send(req,res,200,html,'text/html; charset=utf-8');
 }
 async function body(req,maxBytes=4096){if(!String(req.headers['content-type']||'').toLowerCase().startsWith('application/json'))throw Object.assign(Error('JSON required'),{status:415});const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>maxBytes)throw Object.assign(Error('Request too large'),{status:413});chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch(e){throw Object.assign(Error('Invalid JSON'),{status:400});}}
 const server=http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store, private');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','same-origin');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');if(secure)res.setHeader('Strict-Transport-Security','max-age=31536000');
  try{
   if(req.url==='/healthz'&&['GET','HEAD'].includes(req.method))return send(req,res,200,{ok:true});
   if(req.headers.host!==allowed.host)return send(req,res,400,{error:'Invalid host'});
   const path=new URL(req.url,origin).pathname,method=req.method==='HEAD'?'GET':req.method;
   if(!['GET','POST'].includes(method))return send(req,res,405,{error:'Method not allowed'});
   if(method==='POST'&&req.headers.origin!==allowed.origin)return send(req,res,403,{error:'Request origin rejected'});
   const session=['/dashboard.html','/dashboard','/app','/api/session','/api/logout','/api/state','/api/advisor'].includes(path)?await store.session(token(req)):null;
   if(path==='/api/advisor'&&method==='POST'){if(!session||session.licensed!==1)return send(req,res,401,{error:'يلزم حساب مسجّل ومفعّل.'});if(!same(req.headers['x-csrf-token'],session.csrf))return send(req,res,403,{error:'Request rejected'});return send(req,res,200,await advisor.ask(await body(req,40000)));}
   if(path==='/api/password/status'&&method==='GET'){if(!store.cloud)return send(req,res,503,{error:'استعادة البريد تحتاج إعداد Supabase.'});const recovery=store.recovery(token(req,recoveryCookie));return recovery?send(req,res,200,recovery):send(req,res,403,{error:'يلزم رابط استعادة صالح.'});}
   if(path==='/api/password/forgot'&&method==='POST'){if(!store.cloud)return send(req,res,503,{error:'إرسال البريد يحتاج إعداد Supabase وخدمة البريد أولًا.'});const retry=wait('forgot:'+ip(req),5);if(retry)return send(req,res,429,{error:'انتظر قليلًا قبل طلب رابط آخر.'});const data=await body(req);if(typeof data?.email!=='string'||data.email.length>254||!/^\S+@\S+\.\S+$/.test(data.email))return send(req,res,400,{error:'أدخل بريدًا صالحًا.'});await store.requestRecovery(data.email,new URL('/reset-password.html',allowed.origin).href);return send(req,res,200,{ok:true});}
   if(path==='/api/password/prepare'&&method==='POST'){if(!store.cloud)return send(req,res,503,{error:'استعادة البريد تحتاج إعداد Supabase.'});const retry=wait('recovery:'+ip(req),10);if(retry)return send(req,res,429,{error:'انتظر قليلًا قبل المحاولة.'});const reset=await store.prepareRecovery(await body(req,10000));res.setHeader('Set-Cookie',`${recoveryCookie}=${reset.token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=600${secure?'; Secure':''}`);return send(req,res,200,{csrf:reset.csrf,expires:reset.expires});}
   if(path==='/api/password/reset'&&method==='POST'){if(!store.cloud)return send(req,res,503,{error:'استعادة البريد تحتاج إعداد Supabase.'});const reset=store.recovery(token(req,recoveryCookie));if(!reset||!same(req.headers['x-csrf-token'],reset.csrf))return send(req,res,403,{error:'رابط الاستعادة غير صالح أو انتهى.'});const data=await body(req);await store.resetPassword(token(req,recoveryCookie),data?.password);setCookie(res,'',0);res.appendHeader('Set-Cookie',`${recoveryCookie}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure?'; Secure':''}`);return send(req,res,200,{ok:true});}
   if(path==='/api/checkout'&&method==='POST'){return send(req,res,200,await createCheckout({request:req,response:res,origin:allowed.origin,store}));}
   if(path==='/api/payment/complete'&&method==='POST'){return send(req,res,200,await completePayment({request:req,response:res,payload:await body(req),origin:allowed.origin,store}));}
   if(path==='/api/signup-ticket'&&method==='POST'){if(!store.cloud)return send(req,res,503,{error:'التسجيل السحابي يحتاج إعداد Supabase وربط الشراء.'});const retry=wait('ticket:'+ip(req),30);if(retry)return send(req,res,429,{error:'انتظر قليلًا قبل المحاولة.'});const data=await body(req);return send(req,res,200,await store.ticket(data?.claim));}
   if(path==='/api/signup'&&method==='POST'){
    if(!store.cloud)return send(req,res,503,{error:'التسجيل السحابي يحتاج إعداد Supabase وربط الشراء.'});const retry=wait('signup:'+ip(req),5);if(retry)return send(req,res,429,{error:'محاولات كثيرة. انتظر قليلًا.'});
    const data=await body(req);if(!data||typeof data.email!=='string'||data.email.length>254||!/^\S+@\S+\.\S+$/.test(data.email)||typeof data.password!=='string'||data.password.length<12||data.password.length>256||typeof data.claim!=='string')return send(req,res,400,{error:'راجع البريد وكلمة المرور؛ الحد الأدنى 12 حرفًا.'});
    await store.signup(data.claim,data.email,data.password);const login=await store.login(data.email,data.password);if(login?.licensed){setCookie(res,login.token,43200);return send(req,res,201,{ok:true,next:'/dashboard.html'});}return send(req,res,202,{ok:true,next:'/login.html'});
   }
   if(path==='/api/state'){
    if(!session||session.licensed!==1)return send(req,res,session?403:401,{error:'يلزم حساب مفعّل.'});
    if(!store.cloud)return send(req,res,503,{error:'الحفظ السحابي غير مفعّل في وضع المعاينة المحلية.'});
    if(method==='GET')return send(req,res,200,await store.loadState(session));
    if(!same(req.headers['x-csrf-token'],session.csrf))return send(req,res,403,{error:'Request rejected'});
    const retry=wait('save:'+session.id,180);if(retry)return send(req,res,429,{error:'محاولات حفظ كثيرة. انتظر قليلًا.'});const data=await body(req,2100000);return send(req,res,200,await store.saveState(session,data?.entries,data?.revision));
   }
   if(path==='/api/login'&&method==='POST'){
    const retry=wait('login:'+ip(req));if(retry||activeLogins>=4)return send(req,res,429,{error:'محاولات كثيرة. انتظر قليلًا ثم حاول مجددًا.'},undefined,{'Retry-After':String(retry||3)});
    const data=await body(req);if(!data||typeof data.email!=='string'||data.email.length>254||typeof data.password!=='string'||data.password.length<12||data.password.length>256)return send(req,res,401,{error:'البريد الإلكتروني أو كلمة المرور غير صحيحة.'});
    activeLogins++;let login;try{login=await store.login(data.email,data.password);}finally{activeLogins--;}
    if(!login)return send(req,res,401,{error:'البريد الإلكتروني أو كلمة المرور غير صحيحة.'});
    if(!login.licensed){await store.logout(login.token);return send(req,res,403,{error:'لم تُفعّل صلاحية شراء ربحي لهذا الحساب بعد.'});}
    setCookie(res,login.token,43200);return send(req,res,200,{ok:true,next:'/dashboard.html'});
   }
   if(path==='/api/session'&&method==='GET'){if(!session)return send(req,res,401,{error:'يلزم تسجيل الدخول.'});if(session.licensed!==1)return send(req,res,403,{error:'الحساب غير مفعّل.'});return send(req,res,200,{id:session.id,email:session.email,csrf:session.csrf,licensed:true,expires:session.expires,storage:store.cloud?'cloud':'local'});}
   if(path==='/api/logout'&&method==='POST'){if(!session||!same(req.headers['x-csrf-token'],session.csrf))return send(req,res,403,{error:'Request rejected'});await store.logout(token(req));setCookie(res,'',0);return send(req,res,200,{ok:true});}
   if(method==='POST')return send(req,res,404,{error:'Not found'});
   if(['/dashboard.html','/dashboard','/app'].includes(path)){res.setHeader('X-Robots-Tag','noindex, noarchive');if(!session||session.licensed!==1)return send(req,res,302,'','text/plain; charset=utf-8',{Location:'/index.html'});return page(req,res,'private/dashboard.html',session);}
   if(path==='/service-worker.js'){res.setHeader('Service-Worker-Allowed','/');return send(req,res,200,await readFile(join(root,'public','service-worker.js')),'application/javascript; charset=utf-8',{'Cache-Control':'no-cache'});}
   if(path==='/manifest.json')return send(req,res,200,await readFile(join(root,'public','manifest.json')),'application/manifest+json; charset=utf-8');
   if(path==='/offline.html')return page(req,res,'public/offline.html');
   const pwaFiles={'/assets/pwa.js':['assets/pwa.js','application/javascript; charset=utf-8'],'/assets/pwa.css':['assets/pwa.css','text/css; charset=utf-8'],'/icons/icon-192.png':['icons/icon-192.png','image/png'],'/icons/icon-512.png':['icons/icon-512.png','image/png'],'/icons/icon-maskable-512.png':['icons/icon-maskable-512.png','image/png'],'/icons/apple-touch-icon.png':['icons/apple-touch-icon.png','image/png']};
   if(Object.hasOwn(pwaFiles,path)){const [file,type]=pwaFiles[path];return send(req,res,200,await readFile(join(root,'public',file)),type);}
   if(path==='/assets/html2pdf.bundle.min.js')return send(req,res,200,await readFile(join(root,'vendor','html2pdf.bundle.min.js')),'application/javascript; charset=utf-8');
   if(path==='/assets/jspdf.umd.min.js')return send(req,res,200,await readFile(join(root,'vendor','jspdf.umd.min.js')),'application/javascript; charset=utf-8');
   if(path==='/'||path==='/index.html')return page(req,res,'public/index.html');
   if(path==='/forgot-password.html'||path==='/reset-password.html'){res.setHeader('X-Robots-Tag','noindex');return page(req,res,'public'+path);}
   if(path==='/payment-success.html'){res.setHeader('X-Robots-Tag','noindex');return page(req,res,'public/payment-success.html');}
   if(path==='/signup.html'||path==='/signup'){res.setHeader('X-Robots-Tag','noindex');return page(req,res,'public/signup.html');}
   if(path==='/login.html'||path==='/login'){res.setHeader('X-Robots-Tag','noindex');return page(req,res,'public/login.html');}
   if(path==='/robots.txt')return send(req,res,200,'User-agent: *\nAllow: /\nDisallow: /dashboard.html\nDisallow: /api/\nDisallow: /private/\nDisallow: /login.html\nDisallow: /signup.html\n','text/plain; charset=utf-8');
   // Deliberate allowlist: source files, private directory, databases and archives are never static routes.
   return send(req,res,404,{error:'Not found'});
  }catch(error){return send(req,res,error.status||500,{error:error.status?error.message:'تعذّر إتمام الطلب. حاول مجددًا.',...(error.retryAfter?{retryAfter:error.retryAfter}:{})},undefined,error.retryAfter?{'Retry-After':String(error.retryAfter)}:{});}
 });return {server,store};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 loadProjectEnv();
 const port=Number(process.env.PORT||8788),production=process.env.NODE_ENV==='production';const app=createApplication({origin:process.env.PUBLIC_ORIGIN||`http://127.0.0.1:${port}`,production,dbPath:process.env.RIBHI_DB_PATH||join(root,'data',process.env.AUTH_PROVIDER==='supabase'?'cloud-sessions.sqlite':'ribhi.sqlite'),trustedProxyIps:(process.env.TRUSTED_PROXY_IPS||'').split(',').map(ip=>ip.trim()).filter(Boolean)});app.server.listen(port,process.env.HOST||'127.0.0.1',()=>console.log(`ربحي: ${process.env.PUBLIC_ORIGIN||`http://127.0.0.1:${port}`}`));
}
